import React from 'react'

const StreamCreate=()=>{
    return(
        <div>
            StreamCreate
        </div>
    )
}

export default StreamCreate