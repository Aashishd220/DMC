import React from 'react'

const UserHeader=({userId})=>{
    return(
        <div>
            {userId}
        </div>
    )
}

export default UserHeader