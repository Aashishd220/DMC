import React from 'react'
import {BrowserRouter,Route,Link} from 'react-router-dom'

const Check=()=>{
    return(
        <div>
            <Link to="/">Home</Link>
            check
        </div>
    )
}

export default Check;
